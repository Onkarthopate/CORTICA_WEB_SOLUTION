const mongoose = require('mongoose');

const roleSchema = new mongoose.Schema({
  name: { type: String, required: true },
  permissions: { type: [String], required: true }, // e.g., ['read', 'write', 'delete']
});

module.exports = mongoose.model('Role', roleSchema);
