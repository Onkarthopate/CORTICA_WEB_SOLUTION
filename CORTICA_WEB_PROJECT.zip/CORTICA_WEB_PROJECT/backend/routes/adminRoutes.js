const express = require('express');
const { manageUsers, toggleUserAccess } = require('../controllers/adminController');
const { protect } = require('../middlewares/authMiddleware');

const router = express.Router();

router.get('/users', protect, manageUsers);
router.patch('/users/:id/toggle', protect, toggleUserAccess);

module.exports = router;
