const express = require('express');
const { getStudentList, getAttendance } = require('../controllers/teacherController');
const { protect } = require('../middlewares/authMiddleware');

const router = express.Router();

router.get('/students', protect, getStudentList);
router.get('/attendance', protect, getAttendance);

module.exports = router;
