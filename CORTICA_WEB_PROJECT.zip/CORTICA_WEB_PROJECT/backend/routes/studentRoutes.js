const express = require('express');
const { markAttendance, getAttendanceHistory } = require('../controllers/studentController');
const { protect } = require('../middlewares/authMiddleware');
const upload = require('../middlewares/uploadMiddleware');

const router = express.Router();

router.post('/attendance', protect, upload.single('selfie'), markAttendance);
router.get('/attendance/history', protect, getAttendanceHistory);

module.exports = router;
