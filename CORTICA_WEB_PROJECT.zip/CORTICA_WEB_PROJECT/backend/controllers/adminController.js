const User = require('../models/User');

exports.manageUsers = async (req, res) => {
  try {
    const users = await User.find();

    res.status(200).json({ users });
  } catch (error) {
    res.status(500).json({ error: 'Failed to fetch users' });
  }
};

exports.toggleUserAccess = async (req, res) => {
  try {
    const { id } = req.params;
    const user = await User.findById(id);

    user.isActive = !user.isActive;
    await user.save();

    res.status(200).json({ message: 'User access updated', user });
  } catch (error) {
    res.status(500).json({ error: 'Failed to update user access' });
  }
};
