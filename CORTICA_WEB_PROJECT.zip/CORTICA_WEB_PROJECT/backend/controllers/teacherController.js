const User = require('../models/User');
const Attendance = require('../models/Attendance');

exports.getStudentList = async (req, res) => {
  try {
    const students = await User.find({ role: 'student' });

    res.status(200).json({ students });
  } catch (error) {
    res.status(500).json({ error: 'Failed to fetch student list' });
  }
};

exports.getAttendance = async (req, res) => {
  try {
    const { date } = req.query;
    const attendance = await Attendance.find({ date }).populate('user', 'name');

    res.status(200).json({ attendance });
  } catch (error) {
    res.status(500).json({ error: 'Failed to fetch attendance' });
  }
};
