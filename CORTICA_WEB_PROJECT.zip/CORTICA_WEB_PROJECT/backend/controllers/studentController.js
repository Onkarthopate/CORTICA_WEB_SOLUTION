const Attendance = require('../models/Attendance');

exports.markAttendance = async (req, res) => {
  try {
    // Validate req.user
    if (!req.user || !req.user.userId) {
      return res.status(400).json({ error: 'User ID is missing' });
    }
    const { userId } = req.user;

    // Validate req.file
    if (!req.file || !req.file.path) {
      return res.status(400).json({ error: 'Selfie is missing' });
    }
    const selfie = req.file.path;

    console.log('Creating attendance for:', { user: userId, selfie });

    // Create attendance record
    const attendance = await Attendance.create({ user: userId, selfie });

    res.status(201).json({ message: 'Attendance marked', attendance });
  } catch (error) {
    console.error('Error marking attendance:', error);
    res.status(500).json({ error: 'Attendance marking failed' });
  }
};

exports.getAttendanceHistory = async (req, res) => {
  try {
    // Validate req.user
    if (!req.user || !req.user.userId) {
      return res.status(400).json({ error: 'User ID is missing' });
    }
    const { userId } = req.user;

    console.log('Fetching attendance history for:', userId);

    // Fetch attendance history
    const history = await Attendance.find({ user: userId }).sort({ date: -1 });

    res.status(200).json({ history });
  } catch (error) {
    console.error('Error fetching attendance history:', error);
    res.status(500).json({ error: 'Failed to fetch attendance history' });
  }
};